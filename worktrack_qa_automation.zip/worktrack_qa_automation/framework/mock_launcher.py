"""Starts the bundled mock app in a background thread (only when TARGET=mock)."""
import logging
import threading
import time

import requests
from werkzeug.serving import make_server

import config

_server = None


def start_mock_if_needed():
    """Idempotent: start once per test process, wait until it answers HTTP."""
    global _server
    if not config.IS_MOCK or _server is not None:
        return
    from mock_app.server import app
    logging.getLogger('werkzeug').setLevel(logging.ERROR)   # keep test output readable
    _server = make_server("127.0.0.1", config.MOCK_PORT, app, threaded=True)
    threading.Thread(target=_server.serve_forever, daemon=True).start()
    for _ in range(50):
        try:
            requests.get(config.BASE_URL + "/", timeout=1)
            return
        except requests.RequestException:
            time.sleep(0.1)
    raise RuntimeError("Mock app did not start")


def stop_mock():
    global _server
    if _server:
        _server.shutdown()
        _server = None


class MockHooks:
    """Thin client for the mock's /__test__/ endpoints (state reset + time travel)."""

    def __init__(self, base_url):
        self.base = base_url

    def reset(self):
        requests.post(f"{self.base}/__test__/reset", timeout=5)

    def last_reset_token(self, email):
        r = requests.get(f"{self.base}/__test__/last_reset_token", params={"email": email}, timeout=5)
        return r.json()["token"]

    def age(self, what, key, seconds):
        requests.post(f"{self.base}/__test__/age",
                      json={"what": what, "key": key, "seconds": seconds}, timeout=5)

    def active_sessions(self, email):
        r = requests.get(f"{self.base}/__test__/active_sessions", params={"email": email}, timeout=5)
        return r.json()["count"]
