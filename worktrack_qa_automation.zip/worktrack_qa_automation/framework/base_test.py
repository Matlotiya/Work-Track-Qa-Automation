"""
BaseTest - shared fixture for every test class.

  * one browser per test class (fast), a fresh browser CONTEXT per test (isolated cookies)
  * mock state is reset before each test, so tests are independent and order-free
  * on failure a full-page screenshot is saved to reports/screenshots/
  * @requires_mock skips tests that need the mock's time-travel hooks when TARGET=real
"""
import re
import unittest
from datetime import datetime

from playwright.sync_api import sync_playwright

import config
from framework.mock_launcher import MockHooks, start_mock_if_needed
from pages.dashboard_page import DashboardPage
from pages.forgot_password_page import ForgotPasswordPage
from pages.login_page import LoginPage
from pages.reset_password_page import ResetPasswordPage

requires_mock = unittest.skipUnless(
    config.IS_MOCK, "needs mock-only hooks (state reset / time travel); not safe on a real environment")


class BaseTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        start_mock_if_needed()
        cls.hooks = MockHooks(config.BASE_URL)
        cls._pw = sync_playwright().start()
        launcher = getattr(cls._pw, config.BROWSER)
        cls.browser = launcher.launch(headless=config.HEADLESS, slow_mo=config.SLOW_MO)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls._pw.stop()

    def setUp(self):
        if config.IS_MOCK:
            self.hooks.reset()
        self.context = self.browser.new_context()
        self.context.set_default_timeout(config.DEFAULT_TIMEOUT_MS)
        self.page = self.context.new_page()
        self.dialogs = []                       # any JS alert/confirm/prompt (XSS detection)
        self.page.on("dialog", self._on_dialog)
        self.login_page = LoginPage(self.page, config.BASE_URL)
        self.dashboard = DashboardPage(self.page, config.BASE_URL)
        self.forgot_page = ForgotPasswordPage(self.page, config.BASE_URL)
        self.reset_page = ResetPasswordPage(self.page, config.BASE_URL)

    def tearDown(self):
        if self._failed():
            self._screenshot()
        self.context.close()

    # ------------------------------------------------------------------ helpers
    def _on_dialog(self, dialog):
        self.dialogs.append(dialog.message)
        dialog.dismiss()

    def _failed(self) -> bool:
        result = getattr(self._outcome, "result", None)
        if result is None:
            return False
        return any(t is self for t, _ in list(result.failures) + list(result.errors))

    def _screenshot(self):
        config.SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
        name = re.sub(r"[^\w.-]", "_", self.id().split(".", 1)[-1])
        path = config.SCREENSHOT_DIR / f"{name}_{datetime.now():%H%M%S}.png"
        try:
            self.page.screenshot(path=str(path), full_page=True)
        except Exception:
            pass

    def new_page_in_fresh_context(self):
        """A second, fully isolated browser (= 'Device B'). Closed automatically."""
        ctx = self.browser.new_context()
        ctx.set_default_timeout(config.DEFAULT_TIMEOUT_MS)
        self.addCleanup(ctx.close)
        return ctx, ctx.new_page()

    def restart_browser_session(self):
        """Simulate 'close and reopen the browser': session cookies vanish, persistent ones stay."""
        kept = [c for c in self.context.cookies() if c.get("expires", -1) > 0]
        self.context.close()
        self.context = self.browser.new_context()
        self.context.set_default_timeout(config.DEFAULT_TIMEOUT_MS)
        self.context.add_cookies(kept)
        self.page = self.context.new_page()
        self.login_page = LoginPage(self.page, config.BASE_URL)
        self.dashboard = DashboardPage(self.page, config.BASE_URL)

    def login_ok(self, email=None, password=None, remember=False):
        """Convenience: full valid login, returns once the dashboard is loaded."""
        from data import test_data as d
        self.login_page.open()
        self.login_page.login(email or d.VALID_EMAIL, password or d.VALID_PASSWORD, remember)
        self.dashboard.wait_until_loaded()

    def request_token(self, email):
        """Trigger 'Forgot Password' through the UI and fetch the emailed token (mock inbox)."""
        self.forgot_page.open().request_reset(email)
        return self.hooks.last_reset_token(email)
