"""
EDGE-CASE tests  (Week 2: TC_LOGIN_029 - TC_LOGIN_035) + extra unexpected-behaviour checks.
"""
import time

from data import test_data as d
from framework.base_test import BaseTest, requires_mock
from pages.dashboard_page import DashboardPage
from pages.login_page import LoginPage


class TestEdgeCases(BaseTest):

    @requires_mock
    def test_TC_LOGIN_029_concurrent_login_from_second_device(self):
        """Was BLOCKED manually (one session slot). Automation uses two isolated browsers.
        Policy asserted: newest login wins; exactly ONE active session (no double tracking)."""
        self.login_ok()                                             # Device A
        _, page_b = self.new_page_in_fresh_context()                # Device B
        LoginPage(page_b, self.login_page.base_url).open().login(d.VALID_EMAIL, d.VALID_PASSWORD)
        DashboardPage(page_b, self.login_page.base_url).wait_until_loaded()
        self.assertEqual(self.hooks.active_sessions(d.VALID_EMAIL), 1, "duplicate active sessions")
        self.dashboard.click_any_action()                           # Device A is kicked out
        self.page.wait_for_url("**/?msg=other_device")
        self.assertEqual(self.login_page.banner_text(), d.MSG_OTHER_DEVICE)

    @requires_mock
    def test_TC_LOGIN_030_session_expires_after_20_min_inactivity(self):
        self.login_ok()
        self.hooks.age("session", d.VALID_EMAIL, 20 * 60 + 5)
        self.dashboard.click_any_action()
        self.page.wait_for_url("**/?msg=expired")
        self.assertEqual(self.login_page.banner_text(), d.MSG_SESSION_EXPIRED)

    @requires_mock
    def test_TC_LOGIN_030b_session_alive_at_19_min(self):
        self.login_ok()
        self.hooks.age("session", d.VALID_EMAIL, 19 * 60)
        self.dashboard.click_any_action()
        self.page.wait_for_selector("#activity:has-text('Activity refreshed')")

    def test_TC_LOGIN_031_back_button_after_logout_does_not_show_dashboard(self):
        self.login_ok()
        self.dashboard.logout()
        self.page.wait_for_url("**/?msg=logged_out")
        self.page.go_back()
        self.page.wait_for_load_state()
        self.assertFalse(self.dashboard.is_loaded(), "cached dashboard visible after logout")
        self.assertIn("Login", self.page.title())

    @requires_mock
    def test_TC_LOGIN_032_lockout_clears_after_15_minutes(self):
        for _ in range(5):
            self.login_page.open().login(d.VALID_EMAIL, "Wrong1!x")
            self.page.wait_for_timeout(150)
        self.login_page.wait_for_error(d.MSG_LOCKED)
        self.hooks.age("lockout", d.VALID_EMAIL, 15 * 60 + 1)
        self.login_page.login(d.VALID_EMAIL, d.VALID_PASSWORD)
        self.dashboard.wait_until_loaded()

    def test_TC_LOGIN_033_network_loss_shows_clear_error_and_retry_works(self):
        self.login_page.open()
        self.context.set_offline(True)
        self.login_page.login(d.VALID_EMAIL, d.VALID_PASSWORD)
        self.login_page.wait_for_error("check your connection")
        self.assertEqual(self.login_page.error_text(), d.MSG_NETWORK)
        self.assertNotIn("/dashboard", self.page.url)
        self.context.set_offline(False)
        self.page.click(self.login_page.LOGIN_BTN)                 # retry
        self.dashboard.wait_until_loaded()

    def test_TC_LOGIN_034_5000_char_email_handled_gracefully(self):
        """KNOWN DEFECT WT-131: page freezes and server answers 500 -> FAILS on 'as found' build."""
        statuses = []
        self.page.on("response", lambda r: statuses.append(r.status) if "/api/login" in r.url else None)
        self.login_page.open()
        start = time.time()
        self.login_page.login(d.LONG_EMAIL, d.VALID_PASSWORD)
        self.page.wait_for_timeout(2500)
        self.assertFalse([s for s in statuses if s >= 500], f"WT-131: server returned HTTP {statuses}")
        self.assertIn(d.MSG_EMAIL_FORMAT, self.login_page.email_error_text() + self.login_page.error_text())
        self.assertLess(time.time() - start, 5, "WT-131: page hung on very long input")

    def test_TC_LOGIN_035_unicode_password_logs_in(self):
        self.login_ok(*d.UNICODE_USER)
        self.assertTrue(self.dashboard.is_loaded())

    # ---------------- extra "unexpected user behaviour" checks (not in Week 2) ----------------
    def test_EXT_01_dashboard_url_without_login_redirects_to_login(self):
        self.dashboard.open()
        self.assertFalse(self.dashboard.is_loaded())
        self.assertTrue(self.page.is_visible(self.login_page.LOGIN_BTN))

    def test_EXT_02_tampered_session_cookie_is_rejected(self):
        self.login_ok()
        self.context.add_cookies([{"name": "wt_session", "value": "tampered123",
                                   "url": self.login_page.base_url}])
        self.dashboard.open()
        self.assertFalse(self.dashboard.is_loaded())

    def test_EXT_03_enter_key_and_double_click_do_not_create_two_sessions(self):
        self.login_page.open()
        self.page.fill(self.login_page.EMAIL, d.VALID_EMAIL)
        self.page.fill(self.login_page.PASSWORD, d.VALID_PASSWORD)
        self.page.dblclick(self.login_page.LOGIN_BTN)
        self.dashboard.wait_until_loaded()
        if self.hooks:  # mock only: still exactly one active session
            from config import IS_MOCK
            if IS_MOCK:
                self.assertEqual(self.hooks.active_sessions(d.VALID_EMAIL), 1)
