"""
BOUNDARY tests  (Week 2: TC_LOGIN_011 - TC_LOGIN_018)
Exactly at / just below / just above each documented limit.
"""
from data import test_data as d
from framework.base_test import BaseTest, requires_mock

EMAIL = d.VALID_EMAIL


class TestPasswordLengthBoundaries(BaseTest):
    """Password 8-16 chars. Set-password rules are exercised through the reset-link screen."""

    def _set_password(self, pw):
        token = self.request_token(EMAIL)
        self.reset_page.open_with_token(token)
        return self.reset_page.set_password(pw)

    def test_TC_LOGIN_011_8_char_password_can_log_in(self):
        """Minimum length (8) account authenticates."""
        self.login_ok(*d.EIGHT_CHAR_USER)
        self.assertTrue(self.dashboard.is_loaded())

    @requires_mock
    def test_TC_LOGIN_011b_8_char_password_accepted_on_reset(self):
        self.assertIn("updated", self._set_password(d.PW_8))

    @requires_mock
    def test_TC_LOGIN_012_7_char_password_rejected(self):
        self.assertEqual(self._set_password(d.PW_7), d.MSG_TOO_SHORT)

    @requires_mock
    def test_TC_LOGIN_013_16_char_password_accepted(self):
        self.assertIn("updated", self._set_password(d.PW_16))

    @requires_mock
    def test_TC_LOGIN_014_17_char_password_rejected(self):
        """KNOWN DEFECT WT-114: upper limit not enforced -> this test FAILS on the 'as found' build."""
        msg = self._set_password(d.PW_17)
        self.assertEqual(msg, d.MSG_TOO_LONG, "WT-114: 17-char password was accepted (limit is 16)")


@requires_mock
class TestLockoutBoundaries(BaseTest):
    """CAPTCHA at attempt 3, lock at attempt 5, nothing special at attempt 4."""

    def _fail(self, n):
        self.login_page.open()
        for _ in range(n):
            self.login_page.login(EMAIL, "Wrong1!x")
            self.page.wait_for_function(
                "document.querySelector('#login-error').innerText.length>0")
            self.page.wait_for_timeout(50)

    def test_TC_LOGIN_015_captcha_appears_on_3rd_failure_not_before(self):
        self._fail(2)
        self.assertFalse(self.login_page.captcha_visible(), "CAPTCHA shown too early")
        self._fail(1)
        self.assertTrue(self.login_page.captcha_visible(), "CAPTCHA missing after 3rd failure")

    def test_TC_LOGIN_016_5th_failure_locks_account_even_for_correct_password(self):
        self._fail(5)
        self.assertEqual(self.login_page.error_text(), d.MSG_LOCKED)
        self.login_page.login(EMAIL, d.VALID_PASSWORD)          # correct password now
        self.login_page.wait_for_error(d.MSG_LOCKED)
        self.assertNotIn("dashboard", self.page.url)

    def test_TC_LOGIN_017_4th_failure_does_not_lock(self):
        self._fail(4)
        self.assertEqual(self.login_page.error_text(), d.MSG_INVALID_CREDS)
        self.assertTrue(self.login_page.captcha_visible())
        self.login_page.login(EMAIL, d.VALID_PASSWORD)          # 5th attempt still allowed
        self.dashboard.wait_until_loaded()


@requires_mock
class TestResetLinkExpiryBoundary(BaseTest):
    """Reset link valid for 30 minutes. Time travel replaces a 30-minute wait."""

    def test_TC_LOGIN_018_link_rejected_at_30min_1sec(self):
        token = self.request_token(EMAIL)
        self.hooks.age("token", token, 30 * 60 + 1)
        self.reset_page.open_with_token(token)
        self.assertEqual(self.reset_page.message(), d.MSG_LINK_EXPIRED)
        self.assertFalse(self.reset_page.form_visible())

    def test_TC_LOGIN_018b_link_still_valid_at_29min_59sec(self):
        token = self.request_token(EMAIL)
        self.hooks.age("token", token, 30 * 60 - 1)
        self.reset_page.open_with_token(token)
        self.assertTrue(self.reset_page.form_visible(), "link expired too early")
