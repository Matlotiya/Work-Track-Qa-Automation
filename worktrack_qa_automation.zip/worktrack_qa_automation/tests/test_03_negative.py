"""
NEGATIVE / SECURITY tests  (Week 2: TC_LOGIN_019 - TC_LOGIN_028)
Invalid, malformed and malicious input must be rejected safely.
Data-driven checks use self.subTest so one bad payload does not hide the others.
"""
from data import test_data as d
from framework.base_test import BaseTest, requires_mock


class TestNegativeLogin(BaseTest):

    def test_TC_LOGIN_019_unregistered_email_gives_same_generic_error(self):
        """No user enumeration: unknown email and wrong password produce identical messages."""
        self.login_page.open().login(d.UNKNOWN_EMAIL, d.VALID_PASSWORD)
        self.login_page.wait_for_error(d.MSG_INVALID_CREDS)
        unknown_msg = self.login_page.error_text()
        self.login_page.login(d.VALID_EMAIL, "WrongPass1!")
        self.page.wait_for_timeout(300)
        self.assertEqual(unknown_msg, self.login_page.error_text(), "responses differ -> user enumeration")

    def test_TC_LOGIN_020_empty_fields_show_inline_errors_and_send_no_request(self):
        requests_seen = []
        self.page.on("request", lambda r: requests_seen.append(r.url) if "/api/login" in r.url else None)
        self.login_page.open()
        self.page.click(self.login_page.LOGIN_BTN)
        self.assertEqual(self.login_page.email_error_text(), d.MSG_EMAIL_REQUIRED)
        self.assertEqual(self.login_page.password_error_text(), d.MSG_PASSWORD_REQUIRED)
        self.page.wait_for_timeout(300)
        self.assertEqual(requests_seen, [], "form was submitted to the server with empty fields")

    def test_TC_LOGIN_021_invalid_email_formats_rejected_client_side(self):
        for bad in d.INVALID_EMAILS:
            with self.subTest(email=bad):
                self.login_page.open().login(bad, d.VALID_PASSWORD)
                self.assertEqual(self.login_page.email_error_text(), d.MSG_EMAIL_FORMAT)

    @requires_mock
    def test_TC_LOGIN_022_weak_new_passwords_rejected_with_specific_message(self):
        for pw, missing in d.WEAK_PASSWORDS:
            with self.subTest(password=pw):
                token = self.request_token(d.VALID_EMAIL)
                self.reset_page.open_with_token(token)
                msg = self.reset_page.set_password(pw)
                self.assertIn("must include", msg)
                self.assertIn(missing, msg)

    def test_TC_LOGIN_023_sql_injection_payloads_do_not_authenticate(self):
        for payload in d.SQLI_PAYLOADS:
            with self.subTest(payload=payload):
                self.login_page.open().login(payload, "anything")
                self.page.wait_for_timeout(300)
                self.assertNotIn("/dashboard", self.page.url)
                body = self.page.inner_text("body").lower()
                for leak in ("sql", "syntax error", "traceback", "exception"):
                    self.assertNotIn(leak, body, "DB/stack details leaked to the user")
        # payload in the PASSWORD field with a real email must not log in either
        self.login_page.open().login(d.VALID_EMAIL, "' OR '1'='1")
        self.login_page.wait_for_error(d.MSG_INVALID_CREDS)

    def test_TC_LOGIN_024_xss_payload_is_not_executed_or_reflected(self):
        self.login_page.open().login(d.XSS_PAYLOAD, d.VALID_PASSWORD)
        self.page.wait_for_timeout(500)
        self.assertEqual(self.dialogs, [], "a JavaScript dialog fired -> XSS executed")
        self.assertEqual(self.page.locator("body script:not([src])").count(), 1,
                         "an extra <script> element was injected into the DOM")   # 1 = the page's own
        self.assertNotIn("<script>alert", self.page.content().split("</h2>", 1)[-1].split("<script>")[0])

    @requires_mock
    def test_TC_LOGIN_025_locked_account_rejects_correct_password_without_resetting_timer(self):
        for _ in range(5):
            self.login_page.open().login(d.VALID_EMAIL, "Wrong1!x")
            self.page.wait_for_timeout(150)
        self.login_page.login(d.VALID_EMAIL, d.VALID_PASSWORD)
        self.login_page.wait_for_error(d.MSG_LOCKED)
        self.hooks.age("lockout", d.VALID_EMAIL, 15 * 60 - 10)     # 10s of lock left...
        self.login_page.login(d.VALID_EMAIL, d.VALID_PASSWORD)     # ...attempt must not extend it
        self.login_page.wait_for_error(d.MSG_LOCKED)
        self.hooks.age("lockout", d.VALID_EMAIL, 11)               # now the original timer is over
        self.login_page.login(d.VALID_EMAIL, d.VALID_PASSWORD)
        self.dashboard.wait_until_loaded()

    @requires_mock
    def test_TC_LOGIN_026_used_reset_link_cannot_be_reused(self):
        token = self.request_token(d.VALID_EMAIL)
        self.reset_page.open_with_token(token)
        self.assertIn("updated", self.reset_page.set_password("NewPass9!"))
        self.reset_page.open_with_token(token)                     # second use
        self.assertEqual(self.reset_page.message(), d.MSG_LINK_USED)
        self.assertFalse(self.reset_page.form_visible())

    def test_TC_LOGIN_027_leading_space_in_password_is_not_trimmed(self):
        """Open BA question in Week 2: behaviour asserted = NO silent trimming."""
        self.login_page.open().login(d.VALID_EMAIL, " " + d.VALID_PASSWORD)
        self.login_page.wait_for_error(d.MSG_INVALID_CREDS)

    @requires_mock
    def test_TC_LOGIN_028_new_password_same_as_current_rejected(self):
        token = self.request_token(d.VALID_EMAIL)
        self.reset_page.open_with_token(token)
        self.assertEqual(self.reset_page.set_password(d.VALID_PASSWORD), d.MSG_SAME_PASSWORD)

    @requires_mock
    def test_TC_LOGIN_028b_mismatched_confirmation_rejected(self):
        token = self.request_token(d.VALID_EMAIL)
        self.reset_page.open_with_token(token)
        self.assertEqual(self.reset_page.set_password("NewPass9!", "Different9!"), "Passwords do not match")

    @requires_mock
    def test_TC_LOGIN_028c_forged_reset_token_rejected(self):
        self.reset_page.open_with_token("not-a-real-token")
        self.assertEqual(self.reset_page.message(), d.MSG_LINK_USED)
