"""
FUNCTIONAL tests  (Week 2: TC_LOGIN_001 - TC_LOGIN_010)
Happy-path behaviour with valid, expected user input.
Run only this file:  python -m unittest tests.test_01_functional -v
"""
from datetime import datetime, timezone

from data import test_data as d
from framework.base_test import BaseTest, requires_mock


class TestFunctionalLogin(BaseTest):

    def test_TC_LOGIN_001_valid_login_reaches_dashboard(self):
        """Valid credentials -> Dashboard, banner shows user+org, tracked-time counter runs."""
        self.login_ok()
        self.assertTrue(self.dashboard.is_loaded())
        self.assertIn("Priya Sharma", self.dashboard.banner_text())
        self.assertIn("Test Org Pvt Ltd", self.dashboard.banner_text())
        self.assertEqual(self.dashboard.agent_status(), "Active")
        first = self.dashboard.tracked_time()
        self.page.wait_for_timeout(2100)                    # counter must be incrementing
        self.assertNotEqual(first, self.dashboard.tracked_time(), "tracked-time counter is not running")

    def test_TC_LOGIN_002_wrong_password_rejected_with_generic_message(self):
        """Correct email + wrong password -> generic error, stays on login page."""
        self.login_page.open().login(d.VALID_EMAIL, "WrongPass1!")
        self.login_page.wait_for_error(d.MSG_INVALID_CREDS)
        self.assertNotIn("dashboard", self.page.url)
        self.assertNotIn("password is incorrect", self.login_page.error_text().lower())  # no field hint

    def test_TC_LOGIN_003_remember_me_sets_30_day_cookie_and_survives_restart(self):
        """'Remember Me' -> persistent cookie ~30 days; still logged in after browser restart."""
        self.login_ok(remember=True)
        cookie = next(c for c in self.context.cookies() if c["name"] == "wt_session")
        days = (cookie["expires"] - datetime.now(timezone.utc).timestamp()) / 86400
        self.assertAlmostEqual(days, 30, delta=1, msg=f"cookie lifetime is {days:.1f} days, expected ~30")
        self.restart_browser_session()
        self.dashboard.open()
        self.assertTrue(self.dashboard.is_loaded(), "user was logged out after browser restart")

    def test_TC_LOGIN_004_without_remember_me_cookie_is_session_only(self):
        """No 'Remember Me' -> session cookie only; login required after browser restart."""
        self.login_ok(remember=False)
        cookie = next(c for c in self.context.cookies() if c["name"] == "wt_session")
        self.assertLessEqual(cookie["expires"], 0, "cookie should have no expiry (session cookie)")
        self.restart_browser_session()
        self.dashboard.open()
        self.assertFalse(self.dashboard.is_loaded())
        self.assertTrue(self.page.is_visible(self.login_page.LOGIN_BTN))

    @requires_mock
    def test_TC_LOGIN_005_forgot_password_sends_reset_link(self):
        """Forgot Password with a registered email -> confirmation + a reset token is issued."""
        msg = self.forgot_page.open().request_reset(d.VALID_EMAIL)
        self.assertEqual(msg, d.MSG_RESET_SENT)
        self.assertIsNotNone(self.hooks.last_reset_token(d.VALID_EMAIL), "no reset email/token generated")

    @requires_mock
    def test_TC_LOGIN_006_reset_with_valid_link_then_login_with_new_password(self):
        """Valid unexpired link -> password changes; new password works, old one does not."""
        token = self.request_token(d.VALID_EMAIL)
        self.reset_page.open_with_token(token)
        self.assertIn("updated", self.reset_page.set_password("NewPass9!"))
        self.login_page.open().login(d.VALID_EMAIL, "NewPass9!")
        self.dashboard.wait_until_loaded()
        # old password no longer valid (fresh context = no session)
        _, page2 = self.new_page_in_fresh_context()
        from pages.login_page import LoginPage
        lp = LoginPage(page2, self.login_page.base_url).open()
        lp.login(d.VALID_EMAIL, d.VALID_PASSWORD)
        lp.wait_for_error(d.MSG_INVALID_CREDS)

    def test_TC_LOGIN_007_logout_ends_session_and_stops_access(self):
        """Logout -> Login page, and the old session can no longer open the dashboard."""
        self.login_ok()
        self.dashboard.logout()
        self.page.wait_for_url("**/?msg=logged_out")
        self.assertEqual(self.login_page.banner_text(), d.MSG_LOGGED_OUT)
        self.dashboard.open()
        self.assertFalse(self.dashboard.is_loaded(), "dashboard still reachable after logout")

    def test_TC_LOGIN_008_password_field_is_masked(self):
        """Typed password is masked (input type=password)."""
        self.login_page.open()
        self.page.fill(self.login_page.PASSWORD, d.VALID_PASSWORD)
        self.assertEqual(self.login_page.password_input_type(), "password")

    def test_TC_LOGIN_009_show_hide_password_toggle(self):
        """Eye icon reveals then re-masks the password."""
        self.login_page.open()
        self.page.fill(self.login_page.PASSWORD, d.VALID_PASSWORD)
        self.login_page.toggle_password_visibility()
        self.assertEqual(self.login_page.password_input_type(), "text")
        self.login_page.toggle_password_visibility()
        self.assertEqual(self.login_page.password_input_type(), "password")

    def test_TC_LOGIN_010_email_match_is_case_insensitive(self):
        """Account registered as Mixed.Case@TestOrg.example logs in with all-lowercase email."""
        self.login_ok(email=d.MIXED_CASE_REGISTERED)
        self.assertTrue(self.dashboard.is_loaded())
        self.assertIn("Mixed Case", self.dashboard.banner_text())
        # and with UPPER case too
        self.dashboard.logout()
        self.page.wait_for_url("**/?msg=logged_out")
        self.login_page.login(d.MIXED_CASE_REGISTERED.upper(), d.VALID_PASSWORD)
        self.dashboard.wait_until_loaded()
