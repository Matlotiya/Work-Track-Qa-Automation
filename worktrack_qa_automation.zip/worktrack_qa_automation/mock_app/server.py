"""
Worktrack Login-Module MOCK (system under test for local/offline runs)
=====================================================================
The real Worktrack login screen (app.worktrack.co.in) blocks automated access, and
lockout/reset tests would lock a real account or spam a real mailbox. So this small
Flask app re-implements the *business rules documented in Week 2* so the automation
suite can run anywhere, deterministically.

Business rules implemented (Week 2, section 1.3):
  * Password 8-16 chars + upper/lower/digit/special      * CAPTCHA after 3 failed attempts
  * Lock for 15 min after 5 failed attempts              * Reset link: 30 min, single use
  * Session timeout: 20 min inactivity                   * Remember Me: 30-day cookie
  * Generic "Invalid Work Email or Password" message     * One active session per user

Seeded defects (ON by default, mirroring what was found in Week 2):
  * WT-114  max password length (16) not enforced on Set Password
  * WT-131  5,000-char Work Email -> slow response + HTTP 500
Start with  MOCK_FIXED=1  to simulate the fixed build (those two tests then pass).

Test-only hooks live under /__test__/ ("time travel" so tests never wait 15-30 minutes).
"""
import os
import re
import secrets
import time
from threading import Lock

from flask import Flask, jsonify, make_response, redirect, request

FIXED = os.environ.get("MOCK_FIXED", "0") == "1"
LOCKOUT_SECONDS = 15 * 60
SESSION_TIMEOUT = 20 * 60
RESET_TTL = 30 * 60
REMEMBER_ME_SECONDS = 30 * 24 * 3600
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

app = Flask(__name__)
_lock = Lock()

SEED_USERS = {
    "priya.sharma@testorg.example": ("Passw0rd!23", "Priya Sharma"),
    "mixed.case@testorg.example": ("Passw0rd!23", "Mixed Case"),
    "boundary8@testorg.example": ("Pass1!ab", "Boundary Eight"),
    "unicode.user@testorg.example": ("Pässw0rd!1", "Unicode User"),
}
users, sessions, tokens = {}, {}, {}


def reset_state():
    """Restore the pristine seed data (called by tests before each test)."""
    users.clear()
    sessions.clear()
    tokens.clear()
    for email, (pw, name) in SEED_USERS.items():
        users[email] = {"password": pw, "name": name, "fails": 0, "locked_until": 0}


reset_state()


def now():
    return time.time()


# --------------------------------------------------------------------------- pages
STYLE = """<style>body{font-family:Arial;max-width:420px;margin:40px auto}
input{display:block;width:100%;margin:6px 0;padding:8px;box-sizing:border-box}
.err{color:#b00020}.ok{color:#0a7a2f}button{padding:8px 14px}</style>"""

LOGIN_HTML = """<!doctype html><html><head><title>Worktrack - Login</title>""" + STYLE + """</head><body>
<h2>Worktrack Login</h2><div id="page-message" class="ok"></div>
<label>Work Email</label><input id="email" name="email" type="text" autocomplete="off">
<div id="email-error" class="err"></div>
<label>Password</label><input id="password" name="password" type="password">
<button id="toggle-password" type="button" aria-label="Show password">&#128065;</button>
<div id="password-error" class="err"></div>
<label><input id="remember-me" type="checkbox" style="display:inline;width:auto"> Remember Me</label>
<div id="captcha" style="display:none"><label><input type="checkbox" style="display:inline;width:auto"> I'm not a robot</label></div>
<div id="login-error" class="err" role="alert"></div>
<button id="login-btn" type="button">Login</button> <a id="forgot-link" href="/forgot">Forgot Password</a>
<script>
const $=id=>document.getElementById(id);
const MSGS={expired:'Your session has expired. Please log in again.',
 logged_out:'You have been logged out',other_device:'Logged in from another device',
 login_required:'Please log in to continue'};
const m=new URLSearchParams(location.search).get('msg'); if(m&&MSGS[m]) $('page-message').textContent=MSGS[m];
$('toggle-password').onclick=()=>{const p=$('password');p.type=p.type==='password'?'text':'password'};
$('login-btn').onclick=async()=>{
  ['email-error','password-error','login-error'].forEach(i=>$(i).textContent='');
  const email=$('email').value, pw=$('password').value; let bad=false;
  if(!email){$('email-error').textContent='Work Email is required';bad=true}
  else if(!/^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$/.test(email)){$('email-error').textContent='Please enter a valid email address';bad=true}
  if(!pw){$('password-error').textContent='Password is required';bad=true}
  if(bad) return;                                   // client-side validation: no API call
  try{
    const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({email,password:pw,remember:$('remember-me').checked})});
    let d={}; try{d=await r.json()}catch(e){d={error:'Oops! Something went wrong...'}}
    if(r.ok){location.href='/dashboard';return}
    $('login-error').textContent=d.error||'Oops! Something went wrong...';
    if(d.captcha) $('captcha').style.display='block';
  }catch(e){$('login-error').textContent='Something went wrong. Please check your connection and try again.'}
};
</script></body></html>"""

FORGOT_HTML = """<!doctype html><html><head><title>Forgot Password</title>""" + STYLE + """</head><body>
<h2>Forgot Password</h2><label>Work Email</label><input id="forgot-email" type="text">
<button id="send-reset" type="button">Send Reset Link</button><div id="forgot-msg"></div>
<script>document.getElementById('send-reset').onclick=async()=>{
 const r=await fetch('/api/forgot',{method:'POST',headers:{'Content-Type':'application/json'},
 body:JSON.stringify({email:document.getElementById('forgot-email').value})});
 document.getElementById('forgot-msg').textContent=(await r.json()).message};</script></body></html>"""

RESET_HTML = """<!doctype html><html><head><title>Set Password</title>""" + STYLE + """</head><body>
<h2>Set / Reset Password</h2><div id="reset-msg"></div>
<div id="reset-form"><input id="new-password" type="password" placeholder="New password">
<input id="confirm-password" type="password" placeholder="Confirm password">
<button id="submit-reset" type="button">Submit</button></div>
<script>const $=id=>document.getElementById(id);
const token=new URLSearchParams(location.search).get('token')||'';
function show(t,ok){const e=$('reset-msg');e.textContent=t;e.className=ok?'ok':'err'}
fetch('/api/reset/check?token='+encodeURIComponent(token)).then(r=>r.json()).then(d=>{
 if(!d.ok){$('reset-form').style.display='none';show(d.message,false)}});
$('submit-reset').onclick=async()=>{
 const r=await fetch('/api/reset',{method:'POST',headers:{'Content-Type':'application/json'},
  body:JSON.stringify({token,password:$('new-password').value,confirm:$('confirm-password').value})});
 const d=await r.json();show(d.message,d.ok);if(d.ok)$('reset-form').style.display='none'};</script></body></html>"""

DASH_HTML = """<!doctype html><html><head><title>Worktrack - Dashboard</title>""" + STYLE + """</head><body>
<div id="user-menu"><button id="user-menu-btn" type="button">Profile</button>
<button id="logout-btn" type="button">Logout</button></div>
<h2 id="welcome-banner">__NAME__ | Test Org Pvt Ltd</h2>
<div>Tracked time today: <span id="tracked-time">00:00:00</span></div>
<div>Tracking agent: <span id="agent-status">Active</span></div>
<button id="refresh-btn" type="button">Refresh activity</button><div id="activity"></div>
<script>const $=id=>document.getElementById(id);let s=0;
setInterval(()=>{s++;const p=n=>String(n).padStart(2,'0');
$('tracked-time').textContent=p(Math.floor(s/3600))+':'+p(Math.floor(s%3600/60))+':'+p(s%60)},1000);
$('refresh-btn').onclick=async()=>{const r=await fetch('/api/activity');
 if(r.status===401){const d=await r.json();location.href='/?msg='+d.reason}else $('activity').textContent='Activity refreshed'};
$('logout-btn').onclick=async()=>{await fetch('/api/logout',{method:'POST'});location.href='/?msg=logged_out'};
</script></body></html>"""


def html(body, status=200):
    resp = make_response(body, status)
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.get("/")
def login_page():
    return html(LOGIN_HTML)


@app.get("/forgot")
def forgot_page():
    return html(FORGOT_HTML)


@app.get("/reset")
def reset_page():
    return html(RESET_HTML)


def session_state():
    """Return (session, reason). reason in {None, login_required, expired, other_device}."""
    sid = request.cookies.get("wt_session")
    s = sessions.get(sid)
    if not s:
        return None, "login_required"
    if s.get("superseded"):
        return None, "other_device"
    if now() - s["last_active"] > SESSION_TIMEOUT:
        sessions.pop(sid, None)
        return None, "expired"
    return s, None


@app.get("/dashboard")
def dashboard():
    with _lock:
        s, reason = session_state()
        if not s:
            return redirect(f"/?msg={reason}")
        s["last_active"] = now()
        return html(DASH_HTML.replace("__NAME__", users[s["email"]]["name"]))


@app.get("/api/activity")
def activity():
    with _lock:
        s, reason = session_state()
        if not s:
            return jsonify(reason=reason), 401
        s["last_active"] = now()
        return jsonify(ok=True)


# --------------------------------------------------------------------------- API
LOCK_MSG = "Account locked. Try again in 15 minutes."


@app.post("/api/login")
def api_login():
    d = request.get_json(silent=True) or {}
    email, pw = (d.get("email") or "").strip().lower(), d.get("password") or ""
    if len(email) > 254:
        if not FIXED:  # WT-131 (seeded defect): slow + HTTP 500
            time.sleep(1.5)
            return jsonify(error="Oops! Something went wrong..."), 500
        return jsonify(error="Please enter a valid email address"), 400
    if not EMAIL_RE.match(email):
        return jsonify(error="Please enter a valid email address"), 400
    with _lock:
        u = users.get(email)
        if not u:  # generic reply: no user enumeration
            return jsonify(error="Invalid Work Email or Password"), 401
        if u["locked_until"] > now():
            return jsonify(error=LOCK_MSG), 423
        if u["locked_until"] and u["locked_until"] <= now():
            u["fails"], u["locked_until"] = 0, 0  # lockout elapsed -> counter reset
        if pw != u["password"]:  # exact compare: no silent trimming
            u["fails"] += 1
            if u["fails"] >= 5:
                u["locked_until"] = now() + LOCKOUT_SECONDS
                return jsonify(error=LOCK_MSG, captcha=True), 423
            return jsonify(error="Invalid Work Email or Password", captcha=u["fails"] >= 3), 401
        u["fails"] = 0
        for s in sessions.values():  # policy: newest login wins
            if s["email"] == email:
                s["superseded"] = True
        sid = secrets.token_hex(16)
        sessions[sid] = {"email": email, "last_active": now()}
        resp = jsonify(ok=True)
        kw = {"max_age": REMEMBER_ME_SECONDS} if d.get("remember") else {}
        resp.set_cookie("wt_session", sid, httponly=True, samesite="Lax", **kw)
        return resp


@app.post("/api/logout")
def api_logout():
    with _lock:
        sessions.pop(request.cookies.get("wt_session"), None)
    resp = jsonify(ok=True)
    resp.delete_cookie("wt_session")
    return resp


@app.post("/api/forgot")
def api_forgot():
    email = ((request.get_json(silent=True) or {}).get("email") or "").strip().lower()
    with _lock:
        if email in users:
            tokens[secrets.token_urlsafe(16)] = {"email": email, "issued": now(), "used": False}
    return jsonify(message="Reset link sent")  # same reply for unknown emails


def token_problem(t):
    rec = tokens.get(t)
    if not rec or rec["used"]:
        return "This link is invalid or has already been used."
    if now() - rec["issued"] > RESET_TTL:
        return "This reset link has expired. Please request a new one."
    return None


@app.get("/api/reset/check")
def reset_check():
    with _lock:
        p = token_problem(request.args.get("token", ""))
    return jsonify(ok=p is None, message=p or "")


@app.post("/api/reset")
def api_reset():
    d = request.get_json(silent=True) or {}
    pw, t = d.get("password") or "", d.get("token", "")
    with _lock:
        p = token_problem(t)
        if p:
            return jsonify(ok=False, message=p), 400
        if pw != d.get("confirm"):
            return jsonify(ok=False, message="Passwords do not match"), 400
        if len(pw) < 8:
            return jsonify(ok=False, message="Password must be at least 8 characters long"), 400
        if len(pw) > 16 and FIXED:  # WT-114: check is missing in the "as found" build
            return jsonify(ok=False, message="Password must not exceed 16 characters"), 400
        checks = (("an uppercase letter", r"[A-Z]"), ("a lowercase letter", r"[a-z]"),
                  ("a digit", r"\d"), ("a special character", r"[!@#$%^&*]"))
        missing = [name for name, rx in checks if not re.search(rx, pw)]
        if missing:
            return jsonify(ok=False, message="Password must include " + ", ".join(missing)), 400
        u = users[tokens[t]["email"]]
        if pw == u["password"]:
            return jsonify(ok=False, message="New password must be different from your current password"), 400
        u["password"] = pw
        tokens[t]["used"] = True
        return jsonify(ok=True, message="Password updated successfully")


# --------------------------------------------------------------------------- test hooks
@app.post("/__test__/reset")
def t_reset():
    with _lock:
        reset_state()
    return jsonify(ok=True)


@app.get("/__test__/last_reset_token")
def t_token():
    email = request.args.get("email", "").lower()
    with _lock:
        mine = [(v["issued"], k) for k, v in tokens.items() if v["email"] == email]
    return jsonify(token=max(mine)[1] if mine else None)


@app.post("/__test__/age")
def t_age():
    """Time travel. JSON: {"what": "token|session|lockout", "key": <token|email>, "seconds": n}"""
    d = request.get_json()
    n = float(d["seconds"])
    with _lock:
        if d["what"] == "token":
            tokens[d["key"]]["issued"] -= n
        elif d["what"] == "session":
            for s in sessions.values():
                if s["email"] == d["key"]:
                    s["last_active"] -= n
        elif d["what"] == "lockout":
            users[d["key"]]["locked_until"] -= n
    return jsonify(ok=True)


@app.get("/__test__/active_sessions")
def t_active():
    email = request.args.get("email", "").lower()
    with _lock:
        n = sum(1 for s in sessions.values() if s["email"] == email and not s.get("superseded"))
    return jsonify(count=n)


if __name__ == "__main__":
    app.run(port=int(os.environ.get("MOCK_PORT", 5055)), threaded=True)
