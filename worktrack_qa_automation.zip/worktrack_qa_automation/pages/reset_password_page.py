"""ResetPasswordPage - the 'Set / Reset Password' screen opened from the emailed link."""
from .base_page import BasePage


class ResetPasswordPage(BasePage):
    PATH = "/reset"

    NEW_PASSWORD = "#new-password"
    CONFIRM = "#confirm-password"
    SUBMIT = "#submit-reset"
    MESSAGE = "#reset-msg"
    FORM = "#reset-form"

    def open_with_token(self, token: str):
        self.open(f"?token={token}")
        # the page validates the token on load; wait for that check to settle
        self.page.wait_for_load_state("networkidle")
        return self

    def form_visible(self) -> bool:
        return self.page.is_visible(self.FORM)

    def set_password(self, password: str, confirm: str = None) -> str:
        """Submit a new password and return the message shown."""
        self.page.fill(self.NEW_PASSWORD, password)
        self.page.fill(self.CONFIRM, password if confirm is None else confirm)
        self.page.click(self.SUBMIT)
        self.page.wait_for_function("document.querySelector('#reset-msg').innerText.length > 0")
        return self.message()

    def message(self) -> str:
        return self.text_of(self.MESSAGE)
