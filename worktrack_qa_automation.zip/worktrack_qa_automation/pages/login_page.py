"""
LoginPage - Page Object for the Worktrack login screen.

Page Object Model: tests never touch selectors directly. If the real app's HTML differs
from the mock, ONLY the LOCATORS below need to change - the tests stay untouched.
"""
from .base_page import BasePage


class LoginPage(BasePage):
    PATH = "/"

    # ---- locators (edit here when pointing at the real app) ----
    EMAIL = "#email"
    PASSWORD = "#password"
    REMEMBER_ME = "#remember-me"
    LOGIN_BTN = "#login-btn"
    TOGGLE_PASSWORD = "#toggle-password"
    FORGOT_LINK = "#forgot-link"
    EMAIL_ERROR = "#email-error"
    PASSWORD_ERROR = "#password-error"
    LOGIN_ERROR = "#login-error"
    CAPTCHA = "#captcha"
    PAGE_MESSAGE = "#page-message"

    # ---- actions ----
    def login(self, email: str, password: str, remember: bool = False):
        """Fill the form and click Login (does not wait for any outcome)."""
        self.page.fill(self.EMAIL, email)
        self.page.fill(self.PASSWORD, password)
        if remember:
            self.page.check(self.REMEMBER_ME)
        self.page.click(self.LOGIN_BTN)
        return self

    def toggle_password_visibility(self):
        self.page.click(self.TOGGLE_PASSWORD)

    def go_to_forgot_password(self):
        self.page.click(self.FORGOT_LINK)

    # ---- state queries ----
    def password_input_type(self) -> str:
        return self.page.get_attribute(self.PASSWORD, "type")

    def error_text(self) -> str:
        """Server-side / generic error shown under the form."""
        return self.text_of(self.LOGIN_ERROR)

    def email_error_text(self) -> str:
        return self.text_of(self.EMAIL_ERROR)

    def password_error_text(self) -> str:
        return self.text_of(self.PASSWORD_ERROR)

    def banner_text(self) -> str:
        return self.text_of(self.PAGE_MESSAGE)

    def captcha_visible(self) -> bool:
        return self.page.is_visible(self.CAPTCHA)

    def wait_for_error(self, contains: str):
        self.page.wait_for_function(
            "([sel, txt]) => document.querySelector(sel).innerText.includes(txt)",
            arg=[self.LOGIN_ERROR, contains])
