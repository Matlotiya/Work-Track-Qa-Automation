"""DashboardPage - the post-login landing page (banner, tracked-time counter, logout)."""
from .base_page import BasePage


class DashboardPage(BasePage):
    PATH = "/dashboard"

    BANNER = "#welcome-banner"
    TRACKED_TIME = "#tracked-time"
    AGENT_STATUS = "#agent-status"
    REFRESH_BTN = "#refresh-btn"
    LOGOUT_BTN = "#logout-btn"

    def is_loaded(self) -> bool:
        return self.page.url.rstrip("/").endswith("/dashboard") and self.page.is_visible(self.BANNER)

    def wait_until_loaded(self):
        self.page.wait_for_url("**/dashboard")
        self.page.wait_for_selector(self.BANNER)
        return self

    def banner_text(self) -> str:
        return self.text_of(self.BANNER)

    def tracked_time(self) -> str:
        return self.text_of(self.TRACKED_TIME)

    def agent_status(self) -> str:
        return self.text_of(self.AGENT_STATUS)

    def click_any_action(self):
        self.page.click(self.REFRESH_BTN)

    def logout(self):
        self.page.click(self.LOGOUT_BTN)
