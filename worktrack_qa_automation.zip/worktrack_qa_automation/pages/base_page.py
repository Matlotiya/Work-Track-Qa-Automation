"""BasePage - small helpers shared by every Page Object."""
from playwright.sync_api import Page


class BasePage:
    PATH = "/"

    def __init__(self, page: Page, base_url: str):
        self.page = page
        self.base_url = base_url

    def open(self, query: str = ""):
        self.page.goto(f"{self.base_url}{self.PATH}{query}")
        return self

    def text_of(self, selector: str) -> str:
        return self.page.inner_text(selector).strip()
