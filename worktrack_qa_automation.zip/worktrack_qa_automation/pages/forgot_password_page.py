"""ForgotPasswordPage - request a password-reset link."""
from .base_page import BasePage


class ForgotPasswordPage(BasePage):
    PATH = "/forgot"

    EMAIL = "#forgot-email"
    SEND_BTN = "#send-reset"
    MESSAGE = "#forgot-msg"

    def request_reset(self, email: str):
        self.page.fill(self.EMAIL, email)
        self.page.click(self.SEND_BTN)
        self.page.wait_for_function("document.querySelector('#forgot-msg').innerText.length > 0")
        return self.text_of(self.MESSAGE)
