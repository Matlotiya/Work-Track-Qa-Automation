"""Test data & expected messages (kept out of the tests so a wording change = 1 edit)."""

# --- users seeded by the mock (same values as the Week 2 test data) -----------------
VALID_EMAIL = "priya.sharma@testorg.example"
VALID_PASSWORD = "Passw0rd!23"
MIXED_CASE_REGISTERED = "mixed.case@testorg.example"     # stored as Mixed.Case@TestOrg.example
EIGHT_CHAR_USER = ("boundary8@testorg.example", "Pass1!ab")
UNICODE_USER = ("unicode.user@testorg.example", "Pässw0rd!1")
UNKNOWN_EMAIL = "nouser@testorg.example"

# --- expected on-screen messages (Week 2 wording) ------------------------------------
MSG_INVALID_CREDS = "Invalid Work Email or Password"
MSG_LOCKED = "Account locked. Try again in 15 minutes."
MSG_EMAIL_REQUIRED = "Work Email is required"
MSG_PASSWORD_REQUIRED = "Password is required"
MSG_EMAIL_FORMAT = "Please enter a valid email address"
MSG_RESET_SENT = "Reset link sent"
MSG_TOO_SHORT = "Password must be at least 8 characters long"
MSG_TOO_LONG = "Password must not exceed 16 characters"
MSG_SAME_PASSWORD = "New password must be different from your current password"
MSG_LINK_EXPIRED = "This reset link has expired. Please request a new one."
MSG_LINK_USED = "This link is invalid or has already been used."
MSG_SESSION_EXPIRED = "Your session has expired. Please log in again."
MSG_LOGGED_OUT = "You have been logged out"
MSG_OTHER_DEVICE = "Logged in from another device"
MSG_NETWORK = "Something went wrong. Please check your connection and try again."

# --- boundary passwords (exact lengths asserted at import time) ----------------------
PW_7 = "Pas1!ab"
PW_8 = "Pass1!ab"
PW_16 = "Passw0rd!234567A"
PW_17 = "Passw0rd!2345678A"
assert (len(PW_7), len(PW_8), len(PW_16), len(PW_17)) == (7, 8, 16, 17), "fix boundary data"

# --- data-driven sets ------------------------------------------------------------------
INVALID_EMAILS = ["priya.sharma@@worktrack", "plainaddress", "no-domain@", "@no-user.example",
                  "spaces in@mail.example"]

# (password, fragment that MUST appear in the validation message)
WEAK_PASSWORDS = [
    ("passwordonly", "uppercase"),
    ("PASSWORDONLY1!", "lowercase"),
    ("Passwordonly!", "digit"),
    ("Passw0rdonly", "special"),
]

SQLI_PAYLOADS = ["' OR '1'='1", "admin'--", "'; DROP TABLE users;--", "\" OR \"\"=\""]
XSS_PAYLOAD = "<script>alert('xss')</script>"
LONG_EMAIL = "a" * 5000 + "@test.com"
